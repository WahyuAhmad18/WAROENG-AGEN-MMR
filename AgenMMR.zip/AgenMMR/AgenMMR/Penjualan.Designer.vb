﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Penjualan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Penjualan))
        Me.btnBatal = New System.Windows.Forms.Button()
        Me.btnCetak = New System.Windows.Forms.Button()
        Me.btnsimpan = New System.Windows.Forms.Button()
        Me.DGPenjualan = New System.Windows.Forms.DataGridView()
        Me.txtHargaBersih = New System.Windows.Forms.Label()
        Me.txtHargaKotor = New System.Windows.Forms.Label()
        Me.txtDisc = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lblDisc = New System.Windows.Forms.Label()
        Me.lblHargaKotor = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtJumlah = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtStok = New System.Windows.Forms.Label()
        Me.txtHarga = New System.Windows.Forms.Label()
        Me.txtNamaBarang = New System.Windows.Forms.Label()
        Me.lblBarang = New System.Windows.Forms.Label()
        Me.txtFakturPenjualan = New System.Windows.Forms.Label()
        Me.lblFakturPenjualan = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lbltxtnmPelanggan = New System.Windows.Forms.Label()
        Me.lblnmPelanggan = New System.Windows.Forms.Label()
        Me.cbBarang = New System.Windows.Forms.ComboBox()
        Me.cbPelanggan = New System.Windows.Forms.ComboBox()
        Me.lblPelanggan = New System.Windows.Forms.Label()
        Me.lblHrgTotal = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        CType(Me.DGPenjualan, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnBatal
        '
        Me.btnBatal.Image = CType(resources.GetObject("btnBatal.Image"), System.Drawing.Image)
        Me.btnBatal.Location = New System.Drawing.Point(244, 408)
        Me.btnBatal.Name = "btnBatal"
        Me.btnBatal.Size = New System.Drawing.Size(78, 89)
        Me.btnBatal.TabIndex = 97
        Me.btnBatal.Text = "Batal"
        Me.btnBatal.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnBatal.UseVisualStyleBackColor = True
        '
        'btnCetak
        '
        Me.btnCetak.Image = CType(resources.GetObject("btnCetak.Image"), System.Drawing.Image)
        Me.btnCetak.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnCetak.Location = New System.Drawing.Point(149, 408)
        Me.btnCetak.Name = "btnCetak"
        Me.btnCetak.Size = New System.Drawing.Size(75, 89)
        Me.btnCetak.TabIndex = 96
        Me.btnCetak.Text = "Cetak"
        Me.btnCetak.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnCetak.UseVisualStyleBackColor = True
        '
        'btnsimpan
        '
        Me.btnsimpan.Image = CType(resources.GetObject("btnsimpan.Image"), System.Drawing.Image)
        Me.btnsimpan.Location = New System.Drawing.Point(59, 408)
        Me.btnsimpan.Name = "btnsimpan"
        Me.btnsimpan.Size = New System.Drawing.Size(75, 89)
        Me.btnsimpan.TabIndex = 95
        Me.btnsimpan.Text = "Simpan"
        Me.btnsimpan.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnsimpan.UseVisualStyleBackColor = True
        '
        'DGPenjualan
        '
        Me.DGPenjualan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGPenjualan.Location = New System.Drawing.Point(367, 130)
        Me.DGPenjualan.Name = "DGPenjualan"
        Me.DGPenjualan.RowTemplate.Height = 28
        Me.DGPenjualan.Size = New System.Drawing.Size(607, 436)
        Me.DGPenjualan.TabIndex = 94
        '
        'txtHargaBersih
        '
        Me.txtHargaBersih.AutoSize = True
        Me.txtHargaBersih.BackColor = System.Drawing.Color.White
        Me.txtHargaBersih.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.txtHargaBersih.ForeColor = System.Drawing.Color.Red
        Me.txtHargaBersih.Location = New System.Drawing.Point(811, 95)
        Me.txtHargaBersih.Name = "txtHargaBersih"
        Me.txtHargaBersih.Size = New System.Drawing.Size(36, 22)
        Me.txtHargaBersih.TabIndex = 93
        Me.txtHargaBersih.Text = "Rp,"
        Me.txtHargaBersih.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtHargaKotor
        '
        Me.txtHargaKotor.AutoSize = True
        Me.txtHargaKotor.BackColor = System.Drawing.Color.White
        Me.txtHargaKotor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.txtHargaKotor.Location = New System.Drawing.Point(811, 76)
        Me.txtHargaKotor.Name = "txtHargaKotor"
        Me.txtHargaKotor.Size = New System.Drawing.Size(36, 22)
        Me.txtHargaKotor.TabIndex = 92
        Me.txtHargaKotor.Text = "Rp,"
        Me.txtHargaKotor.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDisc
        '
        Me.txtDisc.Location = New System.Drawing.Point(473, 92)
        Me.txtDisc.Name = "txtDisc"
        Me.txtDisc.Size = New System.Drawing.Size(91, 26)
        Me.txtDisc.TabIndex = 91
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(687, 97)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(110, 20)
        Me.Label12.TabIndex = 90
        Me.Label12.Text = "Harga Bersih :"
        '
        'lblDisc
        '
        Me.lblDisc.AutoSize = True
        Me.lblDisc.Location = New System.Drawing.Point(366, 96)
        Me.lblDisc.Name = "lblDisc"
        Me.lblDisc.Size = New System.Drawing.Size(100, 20)
        Me.lblDisc.TabIndex = 89
        Me.lblDisc.Text = "DISCOUNT :"
        Me.lblDisc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblHargaKotor
        '
        Me.lblHargaKotor.AutoSize = True
        Me.lblHargaKotor.Location = New System.Drawing.Point(687, 77)
        Me.lblHargaKotor.Name = "lblHargaKotor"
        Me.lblHargaKotor.Size = New System.Drawing.Size(111, 20)
        Me.lblHargaKotor.TabIndex = 88
        Me.lblHargaKotor.Text = "Harga Kotor   :"
        Me.lblHargaKotor.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(40, 323)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(93, 20)
        Me.Label5.TabIndex = 87
        Me.Label5.Text = "Jumlah Jual"
        '
        'txtJumlah
        '
        Me.txtJumlah.Location = New System.Drawing.Point(175, 320)
        Me.txtJumlah.Name = "txtJumlah"
        Me.txtJumlah.Size = New System.Drawing.Size(173, 26)
        Me.txtJumlah.TabIndex = 86
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(70, 285)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 20)
        Me.Label4.TabIndex = 85
        Me.Label4.Text = "* Stok"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(70, 263)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 20)
        Me.Label3.TabIndex = 84
        Me.Label3.Text = "* Harga"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(70, 241)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 20)
        Me.Label2.TabIndex = 83
        Me.Label2.Text = "* Nama"
        '
        'txtStok
        '
        Me.txtStok.AutoSize = True
        Me.txtStok.BackColor = System.Drawing.Color.White
        Me.txtStok.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.txtStok.Location = New System.Drawing.Point(177, 285)
        Me.txtStok.Name = "txtStok"
        Me.txtStok.Size = New System.Drawing.Size(20, 22)
        Me.txtStok.TabIndex = 82
        Me.txtStok.Text = "0"
        '
        'txtHarga
        '
        Me.txtHarga.AutoSize = True
        Me.txtHarga.BackColor = System.Drawing.Color.White
        Me.txtHarga.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.txtHarga.Location = New System.Drawing.Point(177, 263)
        Me.txtHarga.Name = "txtHarga"
        Me.txtHarga.Size = New System.Drawing.Size(20, 22)
        Me.txtHarga.TabIndex = 81
        Me.txtHarga.Text = "0"
        '
        'txtNamaBarang
        '
        Me.txtNamaBarang.AutoSize = True
        Me.txtNamaBarang.BackColor = System.Drawing.Color.White
        Me.txtNamaBarang.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.txtNamaBarang.Location = New System.Drawing.Point(177, 241)
        Me.txtNamaBarang.Name = "txtNamaBarang"
        Me.txtNamaBarang.Size = New System.Drawing.Size(123, 22)
        Me.txtNamaBarang.TabIndex = 80
        Me.txtNamaBarang.Text = "                            "
        '
        'lblBarang
        '
        Me.lblBarang.AutoSize = True
        Me.lblBarang.Location = New System.Drawing.Point(40, 212)
        Me.lblBarang.Name = "lblBarang"
        Me.lblBarang.Size = New System.Drawing.Size(61, 20)
        Me.lblBarang.TabIndex = 76
        Me.lblBarang.Text = "Barang"
        '
        'txtFakturPenjualan
        '
        Me.txtFakturPenjualan.AutoSize = True
        Me.txtFakturPenjualan.BackColor = System.Drawing.Color.White
        Me.txtFakturPenjualan.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.txtFakturPenjualan.Location = New System.Drawing.Point(149, 92)
        Me.txtFakturPenjualan.Name = "txtFakturPenjualan"
        Me.txtFakturPenjualan.Size = New System.Drawing.Size(59, 22)
        Me.txtFakturPenjualan.TabIndex = 73
        Me.txtFakturPenjualan.Text = "            "
        '
        'lblFakturPenjualan
        '
        Me.lblFakturPenjualan.AutoSize = True
        Me.lblFakturPenjualan.Location = New System.Drawing.Point(8, 92)
        Me.lblFakturPenjualan.Name = "lblFakturPenjualan"
        Me.lblFakturPenjualan.Size = New System.Drawing.Size(129, 20)
        Me.lblFakturPenjualan.TabIndex = 72
        Me.lblFakturPenjualan.Text = "Faktur Penjualan"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(307, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(380, 36)
        Me.Label1.TabIndex = 71
        Me.Label1.Text = "Form Transaksi Penjualan"
        '
        'lbltxtnmPelanggan
        '
        Me.lbltxtnmPelanggan.AutoSize = True
        Me.lbltxtnmPelanggan.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbltxtnmPelanggan.Location = New System.Drawing.Point(179, 172)
        Me.lbltxtnmPelanggan.Name = "lbltxtnmPelanggan"
        Me.lbltxtnmPelanggan.Size = New System.Drawing.Size(59, 22)
        Me.lbltxtnmPelanggan.TabIndex = 103
        Me.lbltxtnmPelanggan.Text = "Label4"
        '
        'lblnmPelanggan
        '
        Me.lblnmPelanggan.AutoSize = True
        Me.lblnmPelanggan.Location = New System.Drawing.Point(28, 172)
        Me.lblnmPelanggan.Name = "lblnmPelanggan"
        Me.lblnmPelanggan.Size = New System.Drawing.Size(131, 20)
        Me.lblnmPelanggan.TabIndex = 101
        Me.lblnmPelanggan.Text = "Nama Pelanggan"
        '
        'cbBarang
        '
        Me.cbBarang.FormattingEnabled = True
        Me.cbBarang.Location = New System.Drawing.Point(179, 204)
        Me.cbBarang.Name = "cbBarang"
        Me.cbBarang.Size = New System.Drawing.Size(121, 28)
        Me.cbBarang.TabIndex = 100
        '
        'cbPelanggan
        '
        Me.cbPelanggan.FormattingEnabled = True
        Me.cbPelanggan.Location = New System.Drawing.Point(179, 132)
        Me.cbPelanggan.Name = "cbPelanggan"
        Me.cbPelanggan.Size = New System.Drawing.Size(121, 28)
        Me.cbPelanggan.TabIndex = 99
        '
        'lblPelanggan
        '
        Me.lblPelanggan.AutoSize = True
        Me.lblPelanggan.Location = New System.Drawing.Point(28, 135)
        Me.lblPelanggan.Name = "lblPelanggan"
        Me.lblPelanggan.Size = New System.Drawing.Size(85, 20)
        Me.lblPelanggan.TabIndex = 98
        Me.lblPelanggan.Text = "Pelanggan"
        '
        'lblHrgTotal
        '
        Me.lblHrgTotal.AutoSize = True
        Me.lblHrgTotal.BackColor = System.Drawing.SystemColors.InfoText
        Me.lblHrgTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblHrgTotal.ForeColor = System.Drawing.SystemColors.Control
        Me.lblHrgTotal.Location = New System.Drawing.Point(175, 346)
        Me.lblHrgTotal.Name = "lblHrgTotal"
        Me.lblHrgTotal.Size = New System.Drawing.Size(20, 22)
        Me.lblHrgTotal.TabIndex = 104
        Me.lblHrgTotal.Text = "0"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(44, 349)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 20)
        Me.Label6.TabIndex = 105
        Me.Label6.Text = "Total"
        '
        'Penjualan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(998, 574)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.lblHrgTotal)
        Me.Controls.Add(Me.lbltxtnmPelanggan)
        Me.Controls.Add(Me.lblnmPelanggan)
        Me.Controls.Add(Me.cbBarang)
        Me.Controls.Add(Me.cbPelanggan)
        Me.Controls.Add(Me.lblPelanggan)
        Me.Controls.Add(Me.btnBatal)
        Me.Controls.Add(Me.btnCetak)
        Me.Controls.Add(Me.btnsimpan)
        Me.Controls.Add(Me.DGPenjualan)
        Me.Controls.Add(Me.txtHargaBersih)
        Me.Controls.Add(Me.txtHargaKotor)
        Me.Controls.Add(Me.txtDisc)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.lblDisc)
        Me.Controls.Add(Me.lblHargaKotor)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtJumlah)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtStok)
        Me.Controls.Add(Me.txtHarga)
        Me.Controls.Add(Me.txtNamaBarang)
        Me.Controls.Add(Me.lblBarang)
        Me.Controls.Add(Me.txtFakturPenjualan)
        Me.Controls.Add(Me.lblFakturPenjualan)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Penjualan"
        Me.Text = " Transaksi (Penjualan)"
        CType(Me.DGPenjualan, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnBatal As System.Windows.Forms.Button
    Friend WithEvents btnCetak As System.Windows.Forms.Button
    Friend WithEvents btnsimpan As System.Windows.Forms.Button
    Friend WithEvents DGPenjualan As System.Windows.Forms.DataGridView
    Friend WithEvents txtHargaBersih As System.Windows.Forms.Label
    Friend WithEvents txtHargaKotor As System.Windows.Forms.Label
    Friend WithEvents txtDisc As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents lblDisc As System.Windows.Forms.Label
    Friend WithEvents lblHargaKotor As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtJumlah As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtStok As System.Windows.Forms.Label
    Friend WithEvents txtHarga As System.Windows.Forms.Label
    Friend WithEvents txtNamaBarang As System.Windows.Forms.Label
    Friend WithEvents lblBarang As System.Windows.Forms.Label
    Friend WithEvents txtFakturPenjualan As System.Windows.Forms.Label
    Friend WithEvents lblFakturPenjualan As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lbltxtnmPelanggan As System.Windows.Forms.Label
    Friend WithEvents lblnmPelanggan As System.Windows.Forms.Label
    Friend WithEvents cbBarang As System.Windows.Forms.ComboBox
    Friend WithEvents cbPelanggan As System.Windows.Forms.ComboBox
    Friend WithEvents lblPelanggan As System.Windows.Forms.Label
    Friend WithEvents lblHrgTotal As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
End Class
