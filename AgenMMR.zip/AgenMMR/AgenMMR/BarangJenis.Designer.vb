﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BarangJenis
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(BarangJenis))
        Me.btnHapus = New System.Windows.Forms.Button()
        Me.btnUbah = New System.Windows.Forms.Button()
        Me.dgJenisBarang = New System.Windows.Forms.DataGridView()
        Me.btnsimpan = New System.Windows.Forms.Button()
        Me.txtkodejenis = New System.Windows.Forms.TextBox()
        Me.txtjenisbarang = New System.Windows.Forms.TextBox()
        Me.lblkodejenis = New System.Windows.Forms.Label()
        Me.lbljenisbarang = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.dgJenisBarang, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnHapus
        '
        Me.btnHapus.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHapus.Image = CType(resources.GetObject("btnHapus.Image"), System.Drawing.Image)
        Me.btnHapus.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnHapus.Location = New System.Drawing.Point(372, 179)
        Me.btnHapus.Name = "btnHapus"
        Me.btnHapus.Size = New System.Drawing.Size(81, 65)
        Me.btnHapus.TabIndex = 17
        Me.btnHapus.Text = "Hapus"
        Me.btnHapus.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnHapus.UseVisualStyleBackColor = True
        '
        'btnUbah
        '
        Me.btnUbah.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUbah.Image = CType(resources.GetObject("btnUbah.Image"), System.Drawing.Image)
        Me.btnUbah.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnUbah.Location = New System.Drawing.Point(259, 179)
        Me.btnUbah.Name = "btnUbah"
        Me.btnUbah.Size = New System.Drawing.Size(81, 65)
        Me.btnUbah.TabIndex = 16
        Me.btnUbah.Text = "Ubah"
        Me.btnUbah.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnUbah.UseVisualStyleBackColor = True
        '
        'dgJenisBarang
        '
        Me.dgJenisBarang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgJenisBarang.Location = New System.Drawing.Point(63, 262)
        Me.dgJenisBarang.Name = "dgJenisBarang"
        Me.dgJenisBarang.RowTemplate.Height = 28
        Me.dgJenisBarang.Size = New System.Drawing.Size(487, 193)
        Me.dgJenisBarang.TabIndex = 15
        '
        'btnsimpan
        '
        Me.btnsimpan.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsimpan.ForeColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.btnsimpan.Image = CType(resources.GetObject("btnsimpan.Image"), System.Drawing.Image)
        Me.btnsimpan.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnsimpan.Location = New System.Drawing.Point(137, 179)
        Me.btnsimpan.Name = "btnsimpan"
        Me.btnsimpan.Size = New System.Drawing.Size(91, 65)
        Me.btnsimpan.TabIndex = 14
        Me.btnsimpan.Text = "Simpan"
        Me.btnsimpan.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnsimpan.UseVisualStyleBackColor = True
        '
        'txtkodejenis
        '
        Me.txtkodejenis.Location = New System.Drawing.Point(245, 82)
        Me.txtkodejenis.Name = "txtkodejenis"
        Me.txtkodejenis.Size = New System.Drawing.Size(170, 26)
        Me.txtkodejenis.TabIndex = 13
        '
        'txtjenisbarang
        '
        Me.txtjenisbarang.Location = New System.Drawing.Point(245, 124)
        Me.txtjenisbarang.Name = "txtjenisbarang"
        Me.txtjenisbarang.Size = New System.Drawing.Size(170, 26)
        Me.txtjenisbarang.TabIndex = 12
        '
        'lblkodejenis
        '
        Me.lblkodejenis.AutoSize = True
        Me.lblkodejenis.Location = New System.Drawing.Point(112, 82)
        Me.lblkodejenis.Name = "lblkodejenis"
        Me.lblkodejenis.Size = New System.Drawing.Size(87, 20)
        Me.lblkodejenis.TabIndex = 11
        Me.lblkodejenis.Text = "Kode Jenis"
        '
        'lbljenisbarang
        '
        Me.lbljenisbarang.AutoSize = True
        Me.lbljenisbarang.Location = New System.Drawing.Point(108, 124)
        Me.lbljenisbarang.Name = "lbljenisbarang"
        Me.lbljenisbarang.Size = New System.Drawing.Size(102, 20)
        Me.lbljenisbarang.TabIndex = 10
        Me.lbljenisbarang.Text = "Jenis Barang"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(156, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(279, 36)
        Me.Label1.TabIndex = 18
        Me.Label1.Text = "Form Jenis Barang"
        '
        'BarangJenis
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(612, 469)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnHapus)
        Me.Controls.Add(Me.btnUbah)
        Me.Controls.Add(Me.dgJenisBarang)
        Me.Controls.Add(Me.btnsimpan)
        Me.Controls.Add(Me.txtkodejenis)
        Me.Controls.Add(Me.txtjenisbarang)
        Me.Controls.Add(Me.lblkodejenis)
        Me.Controls.Add(Me.lbljenisbarang)
        Me.Name = "BarangJenis"
        Me.Text = "Data Master (Jenis Barang)"
        CType(Me.dgJenisBarang, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnHapus As System.Windows.Forms.Button
    Friend WithEvents btnUbah As System.Windows.Forms.Button
    Friend WithEvents dgJenisBarang As System.Windows.Forms.DataGridView
    Friend WithEvents btnsimpan As System.Windows.Forms.Button
    Friend WithEvents txtkodejenis As System.Windows.Forms.TextBox
    Friend WithEvents txtjenisbarang As System.Windows.Forms.TextBox
    Friend WithEvents lblkodejenis As System.Windows.Forms.Label
    Friend WithEvents lbljenisbarang As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
