﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Pembelian
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Pembelian))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtFakturPembelian = New System.Windows.Forms.Label()
        Me.lblFakturPembelian = New System.Windows.Forms.Label()
        Me.cmbBarang = New System.Windows.Forms.ComboBox()
        Me.cmbSupplier = New System.Windows.Forms.ComboBox()
        Me.txtNmSupplier = New System.Windows.Forms.Label()
        Me.lblBarang = New System.Windows.Forms.Label()
        Me.lblNamaSupplier = New System.Windows.Forms.Label()
        Me.lblSupplier = New System.Windows.Forms.Label()
        Me.txtStok = New System.Windows.Forms.Label()
        Me.txtHarga = New System.Windows.Forms.Label()
        Me.txtNamaBarang = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtJumlah = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtHargaBersih = New System.Windows.Forms.Label()
        Me.txtHargaKotor = New System.Windows.Forms.Label()
        Me.txtDisc = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lblDisc = New System.Windows.Forms.Label()
        Me.lblHargaKotor = New System.Windows.Forms.Label()
        Me.DGPembelian = New System.Windows.Forms.DataGridView()
        Me.btnsimpan = New System.Windows.Forms.Button()
        Me.btnCetak = New System.Windows.Forms.Button()
        Me.btnBatal = New System.Windows.Forms.Button()
        CType(Me.DGPembelian, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(304, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(385, 36)
        Me.Label1.TabIndex = 43
        Me.Label1.Text = "Form Transaksi Pembelian"
        '
        'txtFakturPembelian
        '
        Me.txtFakturPembelian.AutoSize = True
        Me.txtFakturPembelian.BackColor = System.Drawing.Color.White
        Me.txtFakturPembelian.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.txtFakturPembelian.Location = New System.Drawing.Point(146, 101)
        Me.txtFakturPembelian.Name = "txtFakturPembelian"
        Me.txtFakturPembelian.Size = New System.Drawing.Size(59, 22)
        Me.txtFakturPembelian.TabIndex = 45
        Me.txtFakturPembelian.Text = "            "
        '
        'lblFakturPembelian
        '
        Me.lblFakturPembelian.AutoSize = True
        Me.lblFakturPembelian.Location = New System.Drawing.Point(5, 101)
        Me.lblFakturPembelian.Name = "lblFakturPembelian"
        Me.lblFakturPembelian.Size = New System.Drawing.Size(133, 20)
        Me.lblFakturPembelian.TabIndex = 44
        Me.lblFakturPembelian.Text = "Faktur Pembelian"
        '
        'cmbBarang
        '
        Me.cmbBarang.FormattingEnabled = True
        Me.cmbBarang.Location = New System.Drawing.Point(172, 220)
        Me.cmbBarang.Name = "cmbBarang"
        Me.cmbBarang.Size = New System.Drawing.Size(160, 28)
        Me.cmbBarang.TabIndex = 52
        '
        'cmbSupplier
        '
        Me.cmbSupplier.FormattingEnabled = True
        Me.cmbSupplier.Location = New System.Drawing.Point(172, 147)
        Me.cmbSupplier.Name = "cmbSupplier"
        Me.cmbSupplier.Size = New System.Drawing.Size(160, 28)
        Me.cmbSupplier.TabIndex = 51
        '
        'txtNmSupplier
        '
        Me.txtNmSupplier.AutoSize = True
        Me.txtNmSupplier.BackColor = System.Drawing.Color.White
        Me.txtNmSupplier.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.txtNmSupplier.Location = New System.Drawing.Point(174, 186)
        Me.txtNmSupplier.Name = "txtNmSupplier"
        Me.txtNmSupplier.Size = New System.Drawing.Size(59, 22)
        Me.txtNmSupplier.TabIndex = 49
        Me.txtNmSupplier.Text = "            "
        '
        'lblBarang
        '
        Me.lblBarang.AutoSize = True
        Me.lblBarang.Location = New System.Drawing.Point(37, 221)
        Me.lblBarang.Name = "lblBarang"
        Me.lblBarang.Size = New System.Drawing.Size(61, 20)
        Me.lblBarang.TabIndex = 48
        Me.lblBarang.Text = "Barang"
        '
        'lblNamaSupplier
        '
        Me.lblNamaSupplier.AutoSize = True
        Me.lblNamaSupplier.Location = New System.Drawing.Point(37, 187)
        Me.lblNamaSupplier.Name = "lblNamaSupplier"
        Me.lblNamaSupplier.Size = New System.Drawing.Size(113, 20)
        Me.lblNamaSupplier.TabIndex = 47
        Me.lblNamaSupplier.Text = "Nama Supplier"
        '
        'lblSupplier
        '
        Me.lblSupplier.AutoSize = True
        Me.lblSupplier.Location = New System.Drawing.Point(38, 153)
        Me.lblSupplier.Name = "lblSupplier"
        Me.lblSupplier.Size = New System.Drawing.Size(67, 20)
        Me.lblSupplier.TabIndex = 46
        Me.lblSupplier.Text = "Supplier"
        '
        'txtStok
        '
        Me.txtStok.AutoSize = True
        Me.txtStok.BackColor = System.Drawing.Color.White
        Me.txtStok.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.txtStok.Location = New System.Drawing.Point(174, 294)
        Me.txtStok.Name = "txtStok"
        Me.txtStok.Size = New System.Drawing.Size(20, 22)
        Me.txtStok.TabIndex = 55
        Me.txtStok.Text = "0"
        '
        'txtHarga
        '
        Me.txtHarga.AutoSize = True
        Me.txtHarga.BackColor = System.Drawing.Color.White
        Me.txtHarga.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.txtHarga.Location = New System.Drawing.Point(174, 272)
        Me.txtHarga.Name = "txtHarga"
        Me.txtHarga.Size = New System.Drawing.Size(20, 22)
        Me.txtHarga.TabIndex = 54
        Me.txtHarga.Text = "0"
        '
        'txtNamaBarang
        '
        Me.txtNamaBarang.AutoSize = True
        Me.txtNamaBarang.BackColor = System.Drawing.Color.White
        Me.txtNamaBarang.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.txtNamaBarang.Location = New System.Drawing.Point(174, 250)
        Me.txtNamaBarang.Name = "txtNamaBarang"
        Me.txtNamaBarang.Size = New System.Drawing.Size(123, 22)
        Me.txtNamaBarang.TabIndex = 53
        Me.txtNamaBarang.Text = "                            "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(67, 250)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 20)
        Me.Label2.TabIndex = 56
        Me.Label2.Text = "* Nama"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(67, 272)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 20)
        Me.Label3.TabIndex = 57
        Me.Label3.Text = "* Harga"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(67, 294)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 20)
        Me.Label4.TabIndex = 58
        Me.Label4.Text = "* Stok"
        '
        'txtJumlah
        '
        Me.txtJumlah.Location = New System.Drawing.Point(172, 329)
        Me.txtJumlah.Name = "txtJumlah"
        Me.txtJumlah.Size = New System.Drawing.Size(173, 26)
        Me.txtJumlah.TabIndex = 59
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(37, 332)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(90, 20)
        Me.Label5.TabIndex = 60
        Me.Label5.Text = "Jumlah Beli"
        '
        'txtHargaBersih
        '
        Me.txtHargaBersih.AutoSize = True
        Me.txtHargaBersih.BackColor = System.Drawing.Color.White
        Me.txtHargaBersih.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.txtHargaBersih.ForeColor = System.Drawing.Color.Red
        Me.txtHargaBersih.Location = New System.Drawing.Point(808, 104)
        Me.txtHargaBersih.Name = "txtHargaBersih"
        Me.txtHargaBersih.Size = New System.Drawing.Size(36, 22)
        Me.txtHargaBersih.TabIndex = 66
        Me.txtHargaBersih.Text = "Rp,"
        Me.txtHargaBersih.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtHargaKotor
        '
        Me.txtHargaKotor.AutoSize = True
        Me.txtHargaKotor.BackColor = System.Drawing.Color.White
        Me.txtHargaKotor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.txtHargaKotor.Location = New System.Drawing.Point(808, 85)
        Me.txtHargaKotor.Name = "txtHargaKotor"
        Me.txtHargaKotor.Size = New System.Drawing.Size(36, 22)
        Me.txtHargaKotor.TabIndex = 65
        Me.txtHargaKotor.Text = "Rp,"
        Me.txtHargaKotor.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDisc
        '
        Me.txtDisc.Location = New System.Drawing.Point(470, 101)
        Me.txtDisc.Name = "txtDisc"
        Me.txtDisc.Size = New System.Drawing.Size(91, 26)
        Me.txtDisc.TabIndex = 64
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(684, 106)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(110, 20)
        Me.Label12.TabIndex = 63
        Me.Label12.Text = "Harga Bersih :"
        '
        'lblDisc
        '
        Me.lblDisc.AutoSize = True
        Me.lblDisc.Location = New System.Drawing.Point(363, 105)
        Me.lblDisc.Name = "lblDisc"
        Me.lblDisc.Size = New System.Drawing.Size(100, 20)
        Me.lblDisc.TabIndex = 62
        Me.lblDisc.Text = "DISCOUNT :"
        Me.lblDisc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblHargaKotor
        '
        Me.lblHargaKotor.AutoSize = True
        Me.lblHargaKotor.Location = New System.Drawing.Point(684, 86)
        Me.lblHargaKotor.Name = "lblHargaKotor"
        Me.lblHargaKotor.Size = New System.Drawing.Size(111, 20)
        Me.lblHargaKotor.TabIndex = 61
        Me.lblHargaKotor.Text = "Harga Kotor   :"
        Me.lblHargaKotor.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'DGPembelian
        '
        Me.DGPembelian.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGPembelian.Location = New System.Drawing.Point(364, 139)
        Me.DGPembelian.Name = "DGPembelian"
        Me.DGPembelian.RowTemplate.Height = 28
        Me.DGPembelian.Size = New System.Drawing.Size(607, 436)
        Me.DGPembelian.TabIndex = 67
        '
        'btnsimpan
        '
        Me.btnsimpan.Image = CType(resources.GetObject("btnsimpan.Image"), System.Drawing.Image)
        Me.btnsimpan.Location = New System.Drawing.Point(56, 417)
        Me.btnsimpan.Name = "btnsimpan"
        Me.btnsimpan.Size = New System.Drawing.Size(75, 89)
        Me.btnsimpan.TabIndex = 68
        Me.btnsimpan.Text = "Simpan"
        Me.btnsimpan.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnsimpan.UseVisualStyleBackColor = True
        '
        'btnCetak
        '
        Me.btnCetak.Image = CType(resources.GetObject("btnCetak.Image"), System.Drawing.Image)
        Me.btnCetak.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnCetak.Location = New System.Drawing.Point(146, 417)
        Me.btnCetak.Name = "btnCetak"
        Me.btnCetak.Size = New System.Drawing.Size(75, 89)
        Me.btnCetak.TabIndex = 69
        Me.btnCetak.Text = "Cetak"
        Me.btnCetak.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnCetak.UseVisualStyleBackColor = True
        '
        'btnBatal
        '
        Me.btnBatal.Image = CType(resources.GetObject("btnBatal.Image"), System.Drawing.Image)
        Me.btnBatal.Location = New System.Drawing.Point(241, 417)
        Me.btnBatal.Name = "btnBatal"
        Me.btnBatal.Size = New System.Drawing.Size(78, 89)
        Me.btnBatal.TabIndex = 70
        Me.btnBatal.Text = "Batal"
        Me.btnBatal.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnBatal.UseVisualStyleBackColor = True
        '
        'Pembelian
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(983, 587)
        Me.Controls.Add(Me.btnBatal)
        Me.Controls.Add(Me.btnCetak)
        Me.Controls.Add(Me.btnsimpan)
        Me.Controls.Add(Me.DGPembelian)
        Me.Controls.Add(Me.txtHargaBersih)
        Me.Controls.Add(Me.txtHargaKotor)
        Me.Controls.Add(Me.txtDisc)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.lblDisc)
        Me.Controls.Add(Me.lblHargaKotor)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtJumlah)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtStok)
        Me.Controls.Add(Me.txtHarga)
        Me.Controls.Add(Me.txtNamaBarang)
        Me.Controls.Add(Me.cmbBarang)
        Me.Controls.Add(Me.cmbSupplier)
        Me.Controls.Add(Me.txtNmSupplier)
        Me.Controls.Add(Me.lblBarang)
        Me.Controls.Add(Me.lblNamaSupplier)
        Me.Controls.Add(Me.lblSupplier)
        Me.Controls.Add(Me.txtFakturPembelian)
        Me.Controls.Add(Me.lblFakturPembelian)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Pembelian"
        Me.Text = "Transaksi (Pembelian)"
        CType(Me.DGPembelian, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtFakturPembelian As System.Windows.Forms.Label
    Friend WithEvents lblFakturPembelian As System.Windows.Forms.Label
    Friend WithEvents cmbBarang As System.Windows.Forms.ComboBox
    Friend WithEvents cmbSupplier As System.Windows.Forms.ComboBox
    Friend WithEvents txtNmSupplier As System.Windows.Forms.Label
    Friend WithEvents lblBarang As System.Windows.Forms.Label
    Friend WithEvents lblNamaSupplier As System.Windows.Forms.Label
    Friend WithEvents lblSupplier As System.Windows.Forms.Label
    Friend WithEvents txtStok As System.Windows.Forms.Label
    Friend WithEvents txtHarga As System.Windows.Forms.Label
    Friend WithEvents txtNamaBarang As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtJumlah As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtHargaBersih As System.Windows.Forms.Label
    Friend WithEvents txtHargaKotor As System.Windows.Forms.Label
    Friend WithEvents txtDisc As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents lblDisc As System.Windows.Forms.Label
    Friend WithEvents lblHargaKotor As System.Windows.Forms.Label
    Friend WithEvents DGPembelian As System.Windows.Forms.DataGridView
    Friend WithEvents btnsimpan As System.Windows.Forms.Button
    Friend WithEvents btnCetak As System.Windows.Forms.Button
    Friend WithEvents btnBatal As System.Windows.Forms.Button
End Class
