﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Barang
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Barang))
        Me.DGBarang = New System.Windows.Forms.DataGridView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtCariData = New System.Windows.Forms.TextBox()
        Me.rbStok = New System.Windows.Forms.RadioButton()
        Me.rbNamaBarang = New System.Windows.Forms.RadioButton()
        Me.rbKodeBarang = New System.Windows.Forms.RadioButton()
        Me.btnTutup = New System.Windows.Forms.Button()
        Me.btnBatal = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.btnHapus = New System.Windows.Forms.Button()
        Me.btnsimpan = New System.Windows.Forms.Button()
        Me.txtHargaJual = New System.Windows.Forms.TextBox()
        Me.txthargaBeli = New System.Windows.Forms.TextBox()
        Me.cbSatuan = New System.Windows.Forms.ComboBox()
        Me.cbJenisBarang = New System.Windows.Forms.ComboBox()
        Me.txtNamaBarang = New System.Windows.Forms.TextBox()
        Me.txtKodeBarang = New System.Windows.Forms.TextBox()
        Me.txtstoklbl = New System.Windows.Forms.Label()
        Me.lblStok = New System.Windows.Forms.Label()
        Me.lblHargaJual = New System.Windows.Forms.Label()
        Me.lblhargaBeli = New System.Windows.Forms.Label()
        Me.lblSatuan = New System.Windows.Forms.Label()
        Me.lblJenisBarang = New System.Windows.Forms.Label()
        Me.lblNamaBarang = New System.Windows.Forms.Label()
        Me.lblKodeBarang = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        CType(Me.DGBarang, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'DGBarang
        '
        Me.DGBarang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGBarang.Location = New System.Drawing.Point(26, 342)
        Me.DGBarang.Name = "DGBarang"
        Me.DGBarang.RowTemplate.Height = 28
        Me.DGBarang.Size = New System.Drawing.Size(891, 312)
        Me.DGBarang.TabIndex = 41
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtCariData)
        Me.GroupBox1.Controls.Add(Me.rbStok)
        Me.GroupBox1.Controls.Add(Me.rbNamaBarang)
        Me.GroupBox1.Controls.Add(Me.rbKodeBarang)
        Me.GroupBox1.Location = New System.Drawing.Point(66, 265)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(768, 61)
        Me.GroupBox1.TabIndex = 40
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Cari Berdasarkan"
        '
        'txtCariData
        '
        Me.txtCariData.Location = New System.Drawing.Point(403, 23)
        Me.txtCariData.Name = "txtCariData"
        Me.txtCariData.Size = New System.Drawing.Size(345, 26)
        Me.txtCariData.TabIndex = 20
        '
        'rbStok
        '
        Me.rbStok.AutoSize = True
        Me.rbStok.Location = New System.Drawing.Point(304, 25)
        Me.rbStok.Name = "rbStok"
        Me.rbStok.Size = New System.Drawing.Size(67, 24)
        Me.rbStok.TabIndex = 2
        Me.rbStok.TabStop = True
        Me.rbStok.Text = "Stok"
        Me.rbStok.UseVisualStyleBackColor = True
        '
        'rbNamaBarang
        '
        Me.rbNamaBarang.AutoSize = True
        Me.rbNamaBarang.Location = New System.Drawing.Point(152, 25)
        Me.rbNamaBarang.Name = "rbNamaBarang"
        Me.rbNamaBarang.Size = New System.Drawing.Size(132, 24)
        Me.rbNamaBarang.TabIndex = 1
        Me.rbNamaBarang.TabStop = True
        Me.rbNamaBarang.Text = "Nama Barang"
        Me.rbNamaBarang.UseVisualStyleBackColor = True
        '
        'rbKodeBarang
        '
        Me.rbKodeBarang.AutoSize = True
        Me.rbKodeBarang.Location = New System.Drawing.Point(6, 25)
        Me.rbKodeBarang.Name = "rbKodeBarang"
        Me.rbKodeBarang.Size = New System.Drawing.Size(127, 24)
        Me.rbKodeBarang.TabIndex = 0
        Me.rbKodeBarang.TabStop = True
        Me.rbKodeBarang.Text = "Kode Barang"
        Me.rbKodeBarang.UseVisualStyleBackColor = True
        '
        'btnTutup
        '
        Me.btnTutup.Image = CType(resources.GetObject("btnTutup.Image"), System.Drawing.Image)
        Me.btnTutup.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnTutup.Location = New System.Drawing.Point(842, 174)
        Me.btnTutup.Name = "btnTutup"
        Me.btnTutup.Size = New System.Drawing.Size(75, 66)
        Me.btnTutup.TabIndex = 39
        Me.btnTutup.Text = "Tutup"
        Me.btnTutup.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnTutup.UseVisualStyleBackColor = True
        '
        'btnBatal
        '
        Me.btnBatal.Image = CType(resources.GetObject("btnBatal.Image"), System.Drawing.Image)
        Me.btnBatal.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnBatal.Location = New System.Drawing.Point(798, 102)
        Me.btnBatal.Name = "btnBatal"
        Me.btnBatal.Size = New System.Drawing.Size(75, 66)
        Me.btnBatal.TabIndex = 38
        Me.btnBatal.Text = "Batal"
        Me.btnBatal.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnBatal.UseVisualStyleBackColor = True
        '
        'btnEdit
        '
        Me.btnEdit.Image = CType(resources.GetObject("btnEdit.Image"), System.Drawing.Image)
        Me.btnEdit.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnEdit.Location = New System.Drawing.Point(680, 174)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(75, 66)
        Me.btnEdit.TabIndex = 36
        Me.btnEdit.Text = "Edit"
        Me.btnEdit.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnEdit.UseVisualStyleBackColor = True
        '
        'btnHapus
        '
        Me.btnHapus.Image = CType(resources.GetObject("btnHapus.Image"), System.Drawing.Image)
        Me.btnHapus.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnHapus.Location = New System.Drawing.Point(761, 174)
        Me.btnHapus.Name = "btnHapus"
        Me.btnHapus.Size = New System.Drawing.Size(75, 66)
        Me.btnHapus.TabIndex = 37
        Me.btnHapus.Text = "Hapus"
        Me.btnHapus.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnHapus.UseVisualStyleBackColor = True
        '
        'btnsimpan
        '
        Me.btnsimpan.Image = CType(resources.GetObject("btnsimpan.Image"), System.Drawing.Image)
        Me.btnsimpan.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnsimpan.Location = New System.Drawing.Point(717, 102)
        Me.btnsimpan.Name = "btnsimpan"
        Me.btnsimpan.Size = New System.Drawing.Size(75, 66)
        Me.btnsimpan.TabIndex = 35
        Me.btnsimpan.Text = "Simpan"
        Me.btnsimpan.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnsimpan.UseVisualStyleBackColor = True
        '
        'txtHargaJual
        '
        Me.txtHargaJual.Location = New System.Drawing.Point(487, 135)
        Me.txtHargaJual.Name = "txtHargaJual"
        Me.txtHargaJual.Size = New System.Drawing.Size(156, 26)
        Me.txtHargaJual.TabIndex = 34
        '
        'txthargaBeli
        '
        Me.txthargaBeli.Location = New System.Drawing.Point(487, 103)
        Me.txthargaBeli.Name = "txthargaBeli"
        Me.txthargaBeli.Size = New System.Drawing.Size(156, 26)
        Me.txthargaBeli.TabIndex = 33
        '
        'cbSatuan
        '
        Me.cbSatuan.FormattingEnabled = True
        Me.cbSatuan.Location = New System.Drawing.Point(162, 200)
        Me.cbSatuan.Name = "cbSatuan"
        Me.cbSatuan.Size = New System.Drawing.Size(121, 28)
        Me.cbSatuan.TabIndex = 32
        '
        'cbJenisBarang
        '
        Me.cbJenisBarang.FormattingEnabled = True
        Me.cbJenisBarang.Location = New System.Drawing.Point(162, 166)
        Me.cbJenisBarang.Name = "cbJenisBarang"
        Me.cbJenisBarang.Size = New System.Drawing.Size(121, 28)
        Me.cbJenisBarang.TabIndex = 31
        '
        'txtNamaBarang
        '
        Me.txtNamaBarang.Location = New System.Drawing.Point(162, 133)
        Me.txtNamaBarang.Name = "txtNamaBarang"
        Me.txtNamaBarang.Size = New System.Drawing.Size(100, 26)
        Me.txtNamaBarang.TabIndex = 30
        '
        'txtKodeBarang
        '
        Me.txtKodeBarang.Location = New System.Drawing.Point(162, 100)
        Me.txtKodeBarang.Name = "txtKodeBarang"
        Me.txtKodeBarang.Size = New System.Drawing.Size(100, 26)
        Me.txtKodeBarang.TabIndex = 29
        '
        'txtstoklbl
        '
        Me.txtstoklbl.AutoSize = True
        Me.txtstoklbl.BackColor = System.Drawing.Color.White
        Me.txtstoklbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.txtstoklbl.Location = New System.Drawing.Point(487, 172)
        Me.txtstoklbl.Name = "txtstoklbl"
        Me.txtstoklbl.Size = New System.Drawing.Size(20, 22)
        Me.txtstoklbl.TabIndex = 28
        Me.txtstoklbl.Text = "0"
        Me.txtstoklbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblStok
        '
        Me.lblStok.AutoSize = True
        Me.lblStok.Location = New System.Drawing.Point(379, 174)
        Me.lblStok.Name = "lblStok"
        Me.lblStok.Size = New System.Drawing.Size(42, 20)
        Me.lblStok.TabIndex = 27
        Me.lblStok.Text = "Stok"
        '
        'lblHargaJual
        '
        Me.lblHargaJual.AutoSize = True
        Me.lblHargaJual.Location = New System.Drawing.Point(379, 141)
        Me.lblHargaJual.Name = "lblHargaJual"
        Me.lblHargaJual.Size = New System.Drawing.Size(86, 20)
        Me.lblHargaJual.TabIndex = 26
        Me.lblHargaJual.Text = "Harga Jual"
        '
        'lblhargaBeli
        '
        Me.lblhargaBeli.AutoSize = True
        Me.lblhargaBeli.Location = New System.Drawing.Point(379, 109)
        Me.lblhargaBeli.Name = "lblhargaBeli"
        Me.lblhargaBeli.Size = New System.Drawing.Size(83, 20)
        Me.lblhargaBeli.TabIndex = 25
        Me.lblhargaBeli.Text = "Harga Beli"
        '
        'lblSatuan
        '
        Me.lblSatuan.AutoSize = True
        Me.lblSatuan.Location = New System.Drawing.Point(44, 200)
        Me.lblSatuan.Name = "lblSatuan"
        Me.lblSatuan.Size = New System.Drawing.Size(61, 20)
        Me.lblSatuan.TabIndex = 24
        Me.lblSatuan.Text = "Satuan"
        '
        'lblJenisBarang
        '
        Me.lblJenisBarang.AutoSize = True
        Me.lblJenisBarang.Location = New System.Drawing.Point(44, 166)
        Me.lblJenisBarang.Name = "lblJenisBarang"
        Me.lblJenisBarang.Size = New System.Drawing.Size(102, 20)
        Me.lblJenisBarang.TabIndex = 23
        Me.lblJenisBarang.Text = "Jenis Barang"
        '
        'lblNamaBarang
        '
        Me.lblNamaBarang.AutoSize = True
        Me.lblNamaBarang.Location = New System.Drawing.Point(44, 133)
        Me.lblNamaBarang.Name = "lblNamaBarang"
        Me.lblNamaBarang.Size = New System.Drawing.Size(107, 20)
        Me.lblNamaBarang.TabIndex = 22
        Me.lblNamaBarang.Text = "Nama Barang"
        '
        'lblKodeBarang
        '
        Me.lblKodeBarang.AutoSize = True
        Me.lblKodeBarang.Location = New System.Drawing.Point(44, 103)
        Me.lblKodeBarang.Name = "lblKodeBarang"
        Me.lblKodeBarang.Size = New System.Drawing.Size(102, 20)
        Me.lblKodeBarang.TabIndex = 21
        Me.lblKodeBarang.Text = "Kode Barang"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(377, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(202, 36)
        Me.Label1.TabIndex = 42
        Me.Label1.Text = "Form Barang"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(278, 45)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(410, 17)
        Me.Label2.TabIndex = 43
        Me.Label2.Text = "*) Note : combo box harus disesuaikan kembali saat Edit Data (*"
        '
        'Barang
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(958, 666)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DGBarang)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnTutup)
        Me.Controls.Add(Me.btnBatal)
        Me.Controls.Add(Me.btnEdit)
        Me.Controls.Add(Me.btnHapus)
        Me.Controls.Add(Me.btnsimpan)
        Me.Controls.Add(Me.txtHargaJual)
        Me.Controls.Add(Me.txthargaBeli)
        Me.Controls.Add(Me.cbSatuan)
        Me.Controls.Add(Me.cbJenisBarang)
        Me.Controls.Add(Me.txtNamaBarang)
        Me.Controls.Add(Me.txtKodeBarang)
        Me.Controls.Add(Me.txtstoklbl)
        Me.Controls.Add(Me.lblStok)
        Me.Controls.Add(Me.lblHargaJual)
        Me.Controls.Add(Me.lblhargaBeli)
        Me.Controls.Add(Me.lblSatuan)
        Me.Controls.Add(Me.lblJenisBarang)
        Me.Controls.Add(Me.lblNamaBarang)
        Me.Controls.Add(Me.lblKodeBarang)
        Me.Name = "Barang"
        Me.Text = "Data Master (Barang)"
        CType(Me.DGBarang, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DGBarang As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtCariData As System.Windows.Forms.TextBox
    Friend WithEvents rbStok As System.Windows.Forms.RadioButton
    Friend WithEvents rbNamaBarang As System.Windows.Forms.RadioButton
    Friend WithEvents rbKodeBarang As System.Windows.Forms.RadioButton
    Friend WithEvents btnTutup As System.Windows.Forms.Button
    Friend WithEvents btnBatal As System.Windows.Forms.Button
    Friend WithEvents btnEdit As System.Windows.Forms.Button
    Friend WithEvents btnHapus As System.Windows.Forms.Button
    Friend WithEvents btnsimpan As System.Windows.Forms.Button
    Friend WithEvents txtHargaJual As System.Windows.Forms.TextBox
    Friend WithEvents txthargaBeli As System.Windows.Forms.TextBox
    Friend WithEvents cbSatuan As System.Windows.Forms.ComboBox
    Friend WithEvents cbJenisBarang As System.Windows.Forms.ComboBox
    Friend WithEvents txtNamaBarang As System.Windows.Forms.TextBox
    Friend WithEvents txtKodeBarang As System.Windows.Forms.TextBox
    Friend WithEvents txtstoklbl As System.Windows.Forms.Label
    Friend WithEvents lblStok As System.Windows.Forms.Label
    Friend WithEvents lblHargaJual As System.Windows.Forms.Label
    Friend WithEvents lblhargaBeli As System.Windows.Forms.Label
    Friend WithEvents lblSatuan As System.Windows.Forms.Label
    Friend WithEvents lblJenisBarang As System.Windows.Forms.Label
    Friend WithEvents lblNamaBarang As System.Windows.Forms.Label
    Friend WithEvents lblKodeBarang As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
End Class
