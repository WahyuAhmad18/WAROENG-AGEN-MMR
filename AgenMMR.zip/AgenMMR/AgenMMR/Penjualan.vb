﻿Imports Microsoft.VisualBasic
Imports System.Data.Sql
Public Class Penjualan
    Dim SQL As String
    Dim Proses As New koneksi
    Dim tblJual As DataTable

    Sub Data_Record()
        tblJual = Proses.ExecuteQuery("Select tblPenjualan_Rinci.No, tblPenjualan_Rinci.Kode_Barang,tblBarang.Nama_Barang, tblPenjualan_Rinci.Harga_Jual,tblPenjualan_Rinci.Jumlah, tblPenjualan_Rinci.Sub_Total From tblPenjualan_Rinci Inner Join tblBarang on tblPenjualan_Rinci.Kode_Barang = tblBarang.Kode_Barang Where tblPenjualan_Rinci.Faktur_Penjualan = '" & txtFakturPenjualan.Text & "' order by tblPenjualan_Rinci.No asc")
        DGPenjualan.DataSource = tblJual
        DGPenjualan.Columns(0).Width = 100
    End Sub

    Sub Pelanggan()
        tblJual = Proses.ExecuteQuery("Select * From TblPelanggan order by Kode_Pelanggan asc")
        If tblJual.Rows.Count = 0 Then
        Else
            cbPelanggan.Items.Clear()
            With tblJual.Columns(1)
                For a = 0 To tblJual.Rows.Count - 1
                    cbPelanggan.Items.Add("" & .Table.Rows(a).Item(0) & " - " & .Table.Rows(a).Item(1) & "")
                Next a
            End With
        End If
    End Sub

    Sub Barang()
        tblJual = Proses.ExecuteQuery("Select * From TblBarang order by Kode_Barang asc")
        If tblJual.Rows.Count = 0 Then
        Else
            cbBarang.Items.Clear()
            With tblJual.Columns(1)
                For a = 0 To tblJual.Rows.Count - 1
                    cbBarang.Items.Add("" & .Table.Rows(a).Item(0) & " - " & .Table.Rows(a).Item(1) & "")
                Next a
            End With
        End If
    End Sub

    Sub Faktur_Otomatis()
        tblJual = Proses.ExecuteQuery("Select * From TblPenjualan order by Faktur_Penjualan desc")
        If tblJual.Rows.Count = 0 Then
            txtFakturPenjualan.Text = "0001"
        Else
            With tblJual.Rows(0)
                txtFakturPenjualan.Text = .Item("Faktur_Penjualan")
            End With
            txtFakturPenjualan.Text = Val(txtFakturPenjualan.Text) + 1
            If Len(txtFakturPenjualan.Text) = 1 Then
                txtFakturPenjualan.Text = "000" & txtFakturPenjualan.Text & ""
            ElseIf Len(txtFakturPenjualan.Text) = 2 Then
                txtFakturPenjualan.Text = "00" & txtFakturPenjualan.Text & ""
            ElseIf Len(txtFakturPenjualan.Text) = 3 Then
                txtFakturPenjualan.Text = "0" & txtFakturPenjualan.Text & ""
            ElseIf Len(txtFakturPenjualan.Text) = 4 Then
                txtFakturPenjualan.Text = "" & txtFakturPenjualan.Text & ""
            End If
        End If
    End Sub

    Sub Bersih()
        cbBarang.Text = ""
        txtNamaBarang.Text = ""
        txtHarga.Text = ""
        txtStok.Text = ""
        txtJumlah.Text = ""
        txtDisc.Text = ""
        lblHrgTotal.Text = ""
        cbPelanggan.Enabled = True
        cbBarang.Enabled = True
        cbBarang.Focus()
        Call Pelanggan()
        Call Barang()
        Call Faktur_Otomatis()
        Call Data_Record()
        On Error Resume Next
        Dim Total_Seluruh As Single
        Dim i As Integer
        If DGPenjualan.RowCount > 1 Then
            i = DGPenjualan.CurrentRow.Index
            For i = 0 To DGPenjualan.Rows.Count - 1
                Total_Seluruh = Val(Total_Seluruh) + Val(DGPenjualan.Item(5, i).Value)
            Next
            txtHargaKotor.Text = Total_Seluruh.ToString("#,#")
            lblHrgTotal.Text = txtHargaKotor.Text
        End If
    End Sub
    Private Sub Penjualan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Bersih()
        btnsimpan.Enabled = False
    End Sub

    Private Sub btnsimpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsimpan.Click
        If txtHargaKotor.Text = "" Then
            Exit Sub
        End If
        If txtDisc.Text = "" Then
            txtDisc.Text = "0"
        End If
        SQL = "Insert Into TblPenjualan values ('" & txtFakturPenjualan.Text & "','" & Format(Now, "yyyy/MM/dd") & "','" & Microsoft.VisualBasic.Left(cbPelanggan.Text, 6) & "','" & txtDisc.Text & "','" & Val(Replace(txtHargaBersih.Text, ",", "")) & "')"
        Proses.ExecuteNonQuery(SQL)
        MessageBox.Show("Data Baru telah disimpan..!!", "Penyimpanan Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Call Bersih()
        cbPelanggan.Text = ""
        lblnmPelanggan.Text = ""
        txtHargaKotor.Text = ""
        cbPelanggan.Focus()
    End Sub

    Private Sub txtJumlah_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtJumlah.KeyPress
        Select Case e.KeyChar
            Case Chr(47) To Chr(57)
                txtJumlah.Focus()
            Case Chr(8)
                e.KeyChar = Chr(8)
            Case Chr(13)
                tblJual = Proses.ExecuteQuery("Select * From TblPenjualan_Rinci where Faktur_Penjualan ='" & txtFakturPenjualan.Text & "' and Kode_Barang ='" & Mid(cbBarang.Text, 1, 6) & "'")
                If tblJual.Rows.Count = 0 Then
                    Dim Total = Val(txtHarga.Text) * Val(txtJumlah.Text)
                    SQL = "Insert Into TblPenjualan_Rinci values ('" & txtFakturPenjualan.Text & "','" & DGPenjualan.RowCount & "','" & Mid(cbBarang.Text, 1, 6) & "','" & Val(txtHarga.Text) & "','" & txtJumlah.Text & "','" & Total & "')"
                    Proses.ExecuteNonQuery(SQL)
                    btnsimpan.Enabled = True
                Else
                    MsgBox("Proses Penjualan tidak dapat dilakukan !")
                End If
                Call Bersih()
                Dim Total_Seluruh As Single
                Dim i As Integer
                i = DGPenjualan.CurrentRow.Index
                For i = 0 To DGPenjualan.Rows.Count - 1
                    Total_Seluruh = Val(Total_Seluruh) + Val(DGPenjualan.Item(5, i).Value)
                Next
                txtHargaKotor.Text = Total_Seluruh.ToString("#,#")
                lblHrgTotal.Text = txtHargaKotor.Text
            Case Else
                e.KeyChar = Chr(0)
        End Select
    End Sub

    Private Sub txtJumlah_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtJumlah.TextChanged

    End Sub

    Private Sub txtDisc_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtDisc.TextChanged
        If txtDisc.Text = "" Then
            txtDisc.Text = "0"
        End If
        Dim Disc As Single
        Disc = (Val(Replace(txtHargaKotor.Text, ".", "") * txtDisc.Text)) / 100
        txtHargaBersih.Text = (Val(Replace(txtHargaKotor.Text, ".", "") - Val(Disc))).ToString("#,#")
    End Sub

    Private Sub txtHargaBersih_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtHargaBersih.Click

    End Sub

    Private Sub txtHargaBersih_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtHargaBersih.TextChanged
        If txtHargaBersih.Text = "" Then
            txtHargaBersih.Text = "0"
        End If
    End Sub

    Private Sub cbBarang_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbBarang.SelectedIndexChanged
        tblJual = Proses.ExecuteQuery("Select * From TblBarang where Kode_Barang ='" & Mid(cbBarang.Text, 1, 6) & "'")
        If tblJual.Rows.Count = 0 Then
        Else
            txtNamaBarang.Text = tblJual.Rows(0).Item("Nama_Barang")
            txtHarga.Text = tblJual.Rows(0).Item("Harga_Jual")
            txtStok.Text = tblJual.Rows(0).Item("Stock")
            txtJumlah.Focus()
        End If
    End Sub

    Private Sub cbPelanggan_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbPelanggan.SelectedIndexChanged
        tblJual = Proses.ExecuteQuery("Select * From TblPelanggan where Kode_Pelanggan ='" & Mid(cbPelanggan.Text, 1, 6) & "'")
        If tblJual.Rows.Count = 0 Then
        Else
            lbltxtnmPelanggan.Text = tblJual.Rows(0).Item("Nama_Pelanggan")
        End If
    End Sub

    Private Sub btnCetak_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCetak.Click
        Dim No = InputBox("Masukkan no faktur")
        If No = "" Then
            Exit Sub
        Else
            FakturPenjualan.CrystalReportViewer1.SelectionFormula = "{vw_penjualan.faktur_penjualan} Like '" + No + "'"
            FakturPenjualan.CrystalReportViewer1.RefreshReport()
            FakturPenjualan.Show()
        End If
    End Sub
End Class