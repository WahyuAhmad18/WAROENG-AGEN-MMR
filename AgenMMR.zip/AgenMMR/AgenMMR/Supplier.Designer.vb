﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Supplier
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Supplier))
        Me.DGSupplier = New System.Windows.Forms.DataGridView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtCariData = New System.Windows.Forms.TextBox()
        Me.rbCariKontak = New System.Windows.Forms.RadioButton()
        Me.rbNamaSupplier = New System.Windows.Forms.RadioButton()
        Me.rbKodeSupplier = New System.Windows.Forms.RadioButton()
        Me.btnBatal = New System.Windows.Forms.Button()
        Me.btnHapus = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.btnTutup = New System.Windows.Forms.Button()
        Me.btnsimpan = New System.Windows.Forms.Button()
        Me.txtKontak = New System.Windows.Forms.TextBox()
        Me.txtTelepon = New System.Windows.Forms.TextBox()
        Me.txtalamat = New System.Windows.Forms.TextBox()
        Me.txtNamaSupplier = New System.Windows.Forms.TextBox()
        Me.txtkodeSupplier = New System.Windows.Forms.TextBox()
        Me.lblKontak = New System.Windows.Forms.Label()
        Me.lblTelepon = New System.Windows.Forms.Label()
        Me.lblAlamat = New System.Windows.Forms.Label()
        Me.lblnamaSupplier = New System.Windows.Forms.Label()
        Me.lblkodesupplier = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.DGSupplier, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'DGSupplier
        '
        Me.DGSupplier.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGSupplier.Location = New System.Drawing.Point(454, 179)
        Me.DGSupplier.Name = "DGSupplier"
        Me.DGSupplier.RowTemplate.Height = 28
        Me.DGSupplier.Size = New System.Drawing.Size(782, 502)
        Me.DGSupplier.TabIndex = 41
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtCariData)
        Me.GroupBox1.Controls.Add(Me.rbCariKontak)
        Me.GroupBox1.Controls.Add(Me.rbNamaSupplier)
        Me.GroupBox1.Controls.Add(Me.rbKodeSupplier)
        Me.GroupBox1.Location = New System.Drawing.Point(454, 112)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(768, 260)
        Me.GroupBox1.TabIndex = 40
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Cari Berdasarkan"
        '
        'txtCariData
        '
        Me.txtCariData.Location = New System.Drawing.Point(403, 23)
        Me.txtCariData.Name = "txtCariData"
        Me.txtCariData.Size = New System.Drawing.Size(345, 26)
        Me.txtCariData.TabIndex = 20
        '
        'rbCariKontak
        '
        Me.rbCariKontak.AutoSize = True
        Me.rbCariKontak.Location = New System.Drawing.Point(304, 25)
        Me.rbCariKontak.Name = "rbCariKontak"
        Me.rbCariKontak.Size = New System.Drawing.Size(84, 24)
        Me.rbCariKontak.TabIndex = 2
        Me.rbCariKontak.TabStop = True
        Me.rbCariKontak.Text = "Kontak"
        Me.rbCariKontak.UseVisualStyleBackColor = True
        '
        'rbNamaSupplier
        '
        Me.rbNamaSupplier.AutoSize = True
        Me.rbNamaSupplier.Location = New System.Drawing.Point(152, 25)
        Me.rbNamaSupplier.Name = "rbNamaSupplier"
        Me.rbNamaSupplier.Size = New System.Drawing.Size(138, 24)
        Me.rbNamaSupplier.TabIndex = 1
        Me.rbNamaSupplier.TabStop = True
        Me.rbNamaSupplier.Text = "Nama Supplier"
        Me.rbNamaSupplier.UseVisualStyleBackColor = True
        '
        'rbKodeSupplier
        '
        Me.rbKodeSupplier.AutoSize = True
        Me.rbKodeSupplier.Location = New System.Drawing.Point(6, 25)
        Me.rbKodeSupplier.Name = "rbKodeSupplier"
        Me.rbKodeSupplier.Size = New System.Drawing.Size(133, 24)
        Me.rbKodeSupplier.TabIndex = 0
        Me.rbKodeSupplier.TabStop = True
        Me.rbKodeSupplier.Text = "Kode Supplier"
        Me.rbKodeSupplier.UseVisualStyleBackColor = True
        '
        'btnBatal
        '
        Me.btnBatal.Image = CType(resources.GetObject("btnBatal.Image"), System.Drawing.Image)
        Me.btnBatal.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnBatal.Location = New System.Drawing.Point(270, 440)
        Me.btnBatal.Name = "btnBatal"
        Me.btnBatal.Size = New System.Drawing.Size(75, 66)
        Me.btnBatal.TabIndex = 38
        Me.btnBatal.Text = "Batal"
        Me.btnBatal.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnBatal.UseVisualStyleBackColor = True
        '
        'btnHapus
        '
        Me.btnHapus.Image = CType(resources.GetObject("btnHapus.Image"), System.Drawing.Image)
        Me.btnHapus.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnHapus.Location = New System.Drawing.Point(225, 512)
        Me.btnHapus.Name = "btnHapus"
        Me.btnHapus.Size = New System.Drawing.Size(75, 66)
        Me.btnHapus.TabIndex = 37
        Me.btnHapus.Text = "Hapus"
        Me.btnHapus.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnHapus.UseVisualStyleBackColor = True
        '
        'btnEdit
        '
        Me.btnEdit.Image = CType(resources.GetObject("btnEdit.Image"), System.Drawing.Image)
        Me.btnEdit.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnEdit.Location = New System.Drawing.Point(144, 512)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(75, 66)
        Me.btnEdit.TabIndex = 36
        Me.btnEdit.Text = "Edit"
        Me.btnEdit.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnEdit.UseVisualStyleBackColor = True
        '
        'btnTutup
        '
        Me.btnTutup.Image = CType(resources.GetObject("btnTutup.Image"), System.Drawing.Image)
        Me.btnTutup.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnTutup.Location = New System.Drawing.Point(313, 512)
        Me.btnTutup.Name = "btnTutup"
        Me.btnTutup.Size = New System.Drawing.Size(75, 66)
        Me.btnTutup.TabIndex = 39
        Me.btnTutup.Text = "Tutup"
        Me.btnTutup.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnTutup.UseVisualStyleBackColor = True
        '
        'btnsimpan
        '
        Me.btnsimpan.Image = CType(resources.GetObject("btnsimpan.Image"), System.Drawing.Image)
        Me.btnsimpan.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnsimpan.Location = New System.Drawing.Point(189, 440)
        Me.btnsimpan.Name = "btnsimpan"
        Me.btnsimpan.Size = New System.Drawing.Size(75, 66)
        Me.btnsimpan.TabIndex = 35
        Me.btnsimpan.Text = "Simpan"
        Me.btnsimpan.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnsimpan.UseVisualStyleBackColor = True
        '
        'txtKontak
        '
        Me.txtKontak.Location = New System.Drawing.Point(168, 403)
        Me.txtKontak.Name = "txtKontak"
        Me.txtKontak.Size = New System.Drawing.Size(188, 26)
        Me.txtKontak.TabIndex = 34
        '
        'txtTelepon
        '
        Me.txtTelepon.Location = New System.Drawing.Point(168, 370)
        Me.txtTelepon.Name = "txtTelepon"
        Me.txtTelepon.Size = New System.Drawing.Size(188, 26)
        Me.txtTelepon.TabIndex = 33
        '
        'txtalamat
        '
        Me.txtalamat.Location = New System.Drawing.Point(168, 257)
        Me.txtalamat.Multiline = True
        Me.txtalamat.Name = "txtalamat"
        Me.txtalamat.Size = New System.Drawing.Size(238, 100)
        Me.txtalamat.TabIndex = 32
        '
        'txtNamaSupplier
        '
        Me.txtNamaSupplier.Location = New System.Drawing.Point(168, 224)
        Me.txtNamaSupplier.Name = "txtNamaSupplier"
        Me.txtNamaSupplier.Size = New System.Drawing.Size(238, 26)
        Me.txtNamaSupplier.TabIndex = 31
        '
        'txtkodeSupplier
        '
        Me.txtkodeSupplier.Location = New System.Drawing.Point(168, 187)
        Me.txtkodeSupplier.Name = "txtkodeSupplier"
        Me.txtkodeSupplier.Size = New System.Drawing.Size(100, 26)
        Me.txtkodeSupplier.TabIndex = 30
        '
        'lblKontak
        '
        Me.lblKontak.AutoSize = True
        Me.lblKontak.Location = New System.Drawing.Point(35, 403)
        Me.lblKontak.Name = "lblKontak"
        Me.lblKontak.Size = New System.Drawing.Size(59, 20)
        Me.lblKontak.TabIndex = 29
        Me.lblKontak.Text = "Kontak"
        '
        'lblTelepon
        '
        Me.lblTelepon.AutoSize = True
        Me.lblTelepon.Location = New System.Drawing.Point(35, 370)
        Me.lblTelepon.Name = "lblTelepon"
        Me.lblTelepon.Size = New System.Drawing.Size(66, 20)
        Me.lblTelepon.TabIndex = 28
        Me.lblTelepon.Text = "Telepon"
        '
        'lblAlamat
        '
        Me.lblAlamat.AutoSize = True
        Me.lblAlamat.Location = New System.Drawing.Point(35, 259)
        Me.lblAlamat.Name = "lblAlamat"
        Me.lblAlamat.Size = New System.Drawing.Size(59, 20)
        Me.lblAlamat.TabIndex = 27
        Me.lblAlamat.Text = "Alamat"
        '
        'lblnamaSupplier
        '
        Me.lblnamaSupplier.AutoSize = True
        Me.lblnamaSupplier.Location = New System.Drawing.Point(35, 225)
        Me.lblnamaSupplier.Name = "lblnamaSupplier"
        Me.lblnamaSupplier.Size = New System.Drawing.Size(113, 20)
        Me.lblnamaSupplier.TabIndex = 26
        Me.lblnamaSupplier.Text = "Nama Supplier"
        '
        'lblkodesupplier
        '
        Me.lblkodesupplier.AutoSize = True
        Me.lblkodesupplier.Location = New System.Drawing.Point(35, 189)
        Me.lblkodesupplier.Name = "lblkodesupplier"
        Me.lblkodesupplier.Size = New System.Drawing.Size(108, 20)
        Me.lblkodesupplier.TabIndex = 25
        Me.lblkodesupplier.Text = "Kode Supplier"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Modern No. 20", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(466, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(421, 50)
        Me.Label1.TabIndex = 42
        Me.Label1.Text = "FORM SUPPLIER"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Supplier
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1353, 628)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DGSupplier)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnBatal)
        Me.Controls.Add(Me.btnHapus)
        Me.Controls.Add(Me.btnEdit)
        Me.Controls.Add(Me.btnTutup)
        Me.Controls.Add(Me.btnsimpan)
        Me.Controls.Add(Me.txtKontak)
        Me.Controls.Add(Me.txtTelepon)
        Me.Controls.Add(Me.txtalamat)
        Me.Controls.Add(Me.txtNamaSupplier)
        Me.Controls.Add(Me.txtkodeSupplier)
        Me.Controls.Add(Me.lblKontak)
        Me.Controls.Add(Me.lblTelepon)
        Me.Controls.Add(Me.lblAlamat)
        Me.Controls.Add(Me.lblnamaSupplier)
        Me.Controls.Add(Me.lblkodesupplier)
        Me.Name = "Supplier"
        Me.Text = "Data Master (Supplier)"
        CType(Me.DGSupplier, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DGSupplier As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtCariData As System.Windows.Forms.TextBox
    Friend WithEvents rbCariKontak As System.Windows.Forms.RadioButton
    Friend WithEvents rbNamaSupplier As System.Windows.Forms.RadioButton
    Friend WithEvents rbKodeSupplier As System.Windows.Forms.RadioButton
    Friend WithEvents btnBatal As System.Windows.Forms.Button
    Friend WithEvents btnHapus As System.Windows.Forms.Button
    Friend WithEvents btnEdit As System.Windows.Forms.Button
    Friend WithEvents btnTutup As System.Windows.Forms.Button
    Friend WithEvents btnsimpan As System.Windows.Forms.Button
    Friend WithEvents txtKontak As System.Windows.Forms.TextBox
    Friend WithEvents txtTelepon As System.Windows.Forms.TextBox
    Friend WithEvents txtalamat As System.Windows.Forms.TextBox
    Friend WithEvents txtNamaSupplier As System.Windows.Forms.TextBox
    Friend WithEvents txtkodeSupplier As System.Windows.Forms.TextBox
    Friend WithEvents lblKontak As System.Windows.Forms.Label
    Friend WithEvents lblTelepon As System.Windows.Forms.Label
    Friend WithEvents lblAlamat As System.Windows.Forms.Label
    Friend WithEvents lblnamaSupplier As System.Windows.Forms.Label
    Friend WithEvents lblkodesupplier As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
